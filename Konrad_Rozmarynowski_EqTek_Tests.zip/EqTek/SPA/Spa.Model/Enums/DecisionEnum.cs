﻿namespace Spa.Model.Enums
{
    public enum DecisionEnum
    {
        NotTaken = 0,
        Accepted = 1,
        Rejected = 2
    }
}
