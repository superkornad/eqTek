﻿using System.Collections.Generic;
using Spa.Model.Models;

namespace Spa.Model.Interfaces
{
    public interface ICandidatesData
    {
        IEnumerable<Candidate> GetAll();
        Candidate GetById(int id);

        bool TryCreate(Candidate candidate, out string message);
        bool TryUpdate(Candidate candidate, out string message);
        bool TryDelete(int candidateId, out string message);

    }
}
