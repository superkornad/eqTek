﻿using Spa.Model.Enums;

namespace Spa.Model.Models
{
    public class Candidate
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DecisionEnum  Decision { get; set; }
    }
}
