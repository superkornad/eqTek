﻿using System.Collections.Generic;
using System.Linq;
using Spa.Model.Enums;
using Spa.Model.Interfaces;
using Spa.Model.Models;

namespace Spa.Data.Repositories
{
    public class InMemoryCandidatesData : ICandidatesData
    {
        List<Candidate> _candidates;

        public InMemoryCandidatesData()
        {
            _candidates = new List<Candidate>()
            {
                new Candidate()
                {
                    Id = 1,
                    Name = "John Connor",
                    Decision = DecisionEnum.NotTaken
                },
                new Candidate()
                {
                    Id = 2,
                    Name = "Sarah Connor",
                    Decision = DecisionEnum.Accepted
                },

                new Candidate()
                {
                    Id = 3,
                    Name = "T1000",
                    Decision = DecisionEnum.Rejected
                }
            };
        }

        public IEnumerable<Candidate> GetAll()
        {
            return _candidates;
        }

        public Candidate GetById(int id)
        {
            return _candidates.FirstOrDefault(x => x.Id == id);
        }

        public bool TryUpdate(Candidate candidate, out string message)
        {
            message = string.Empty;
            Candidate cnd;
            try
            {
                cnd = _candidates.Single(x=>x.Id == candidate.Id);
            }
            catch
            {
                message = $"Cannot find candidate with id {candidate.Id}";
                return false;
            }

            cnd.Name = candidate.Name;
            cnd.Decision = candidate.Decision;
            return true;
        }

        public bool TryCreate(Candidate candidate, out string message)
        {
            message = string.Empty;
            if (string.IsNullOrEmpty(candidate.Name))
            {
                message = "Candidate with no name cannot be saved";
                return false;
            }

            if (_candidates.FirstOrDefault(x=>x.Name == candidate.Name) != null)
            {
                message = $"Candidate with the name ${candidate.Name} already exists";
                return false;
            }

            candidate.Id = _candidates.Max(x => x.Id) + 1;
            _candidates.Add(candidate);

            return true;
        }

        public bool TryDelete(int candidateId, out string message)
        {
            message = string.Empty;

            var candidate = _candidates.FirstOrDefault(x => x.Id == candidateId);
            if (candidate == null)
            {
                message = $"Cannot find candidate with id {candidateId}";
                return false;
            }

            _candidates.Remove(candidate);
            return true;
        }
    }
}
