﻿function Site() {
    
    var loadControl = function (url, data, destination) {
        
        return $.get(
            {
                url: url,
                data: data
            }
        ).done(function (data) {
            destination.html(data);
        }).fail(function () {
            destination.html('Error occured');
        });
    };
   
    //interface
    this.loadControl = loadControl;
}

var site = new Site();



