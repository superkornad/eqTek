﻿function Candidates() {

    var formContainer = null;
    var listContainer = null;
    var formUrl = null;
    var listUrl = null;
    var btnAdd = null;

    var bindEditButtons = function (container) {
        $(container).find('button.edit').each(
            function () {
                $(this).on('click',
                    function() {
                        var id = $(this).data('id');
                        loadEditForm(id);
                    });

            });
    };

    var loadList = function () {
        site.loadControl(listUrl, {}, listContainer).then(function() {
            bindEditButtons(listContainer);
        });
    };

    var afterCandidateSave = function () {
        formContainer.html('');
        loadList();
        btnAdd.show();
    };

    var onFormLoaded = function (container) {
        var form = $(container).find('form');
        var btnCancel = $(container).find("button#btnCancel");
        btnAdd.hide();

        btnCancel.on('click', function (e) {
            formContainer.html('');
            btnAdd.show();
        });

        form.on('submit',
            function(e) {
                e.preventDefault();
                var action = $(this).attr("action");
                var data = $(this).serializeArray();
                $.ajax({
                    type: "POST",
                    url: action,
                    data: data,
                    dataType: "json",
                    
                    success: function (data) {
                        if (data.result)
                            afterCandidateSave();
                        else
                            alert(data.message);
                    },
                    error: function () {
                        alert('Error occured');
                    }
                });  
            });
    };

    var loadEditForm = function(id) {
        site.loadControl(formUrl, {id}, formContainer)
            .then(function () { onFormLoaded(formContainer); });
    };

    var initControls = function () {
        formContainer = $('#form-container');
        listContainer = $('#list-container');
        formUrl = formContainer.data('url');
        listUrl = listContainer.data('url');

        loadList();

        btnAdd = $('#btnAdd');
        btnAdd.on('click', function() {
            loadEditForm(0);
        });
    };

    this.initControls = initControls;
}

var candidatesPage = new Candidates();
candidatesPage.initControls();
