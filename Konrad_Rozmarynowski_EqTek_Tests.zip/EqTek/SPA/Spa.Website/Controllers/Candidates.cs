﻿using Microsoft.AspNetCore.Mvc;
using Spa.Model.Interfaces;
using Spa.Model.Models;

namespace SPA.Website.Controllers
{
    public class CandidatesController : Controller
    {
        private readonly ICandidatesData _data;

        public CandidatesController(ICandidatesData data)
        {
            _data = data;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetList()
        {
            return PartialView("Controls/List",_data.GetAll() );
        }

        public IActionResult GetForm(int id = 0)
        {
            var candidate = _data.GetById(id) ?? new Candidate();
            return PartialView("Controls/Form", candidate);
        }

        [HttpPost]
        public JsonResult SaveCandidate(Candidate candidate)
        {
            string message;
            bool result = candidate.Id == 0
                ? _data.TryCreate(candidate, out message)
                : _data.TryUpdate(candidate, out message);

            if(result)
                return Json(new { result = true });

            return Json(new { result = false, message });
        }

    }
}
