﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Data;
using WebApi.Data.Entities;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidatesController : ControllerBase
    {
        private readonly IEqTekData _data;
        public CandidatesController(IEqTekData data)
        {
            _data = data;
        }
        
        [HttpGet]
        public ActionResult<IEnumerable<Candidate>> Get()
        {
            return _data.GetCandidates().ToArray();
        }
        
        [HttpGet("{id}")]
        public ActionResult<Candidate> Get(int id)
        {
            var result =  _data.GetCandidates().FirstOrDefault(x => x.Id == id);
            if (result == null)
                return NotFound();

            return result;
        }
        
        [HttpPost]
        public ActionResult<Candidate> Post([FromBody] Candidate candidate)
        {
            if (!_data.TryAddCandidate(candidate, out string message))
                return this.StatusCode(StatusCodes.Status400BadRequest, message );

            return Created($"api/Candidates/{candidate.Id}", candidate);
        }
        
        [HttpPut("{id}")]
        public ActionResult<Candidate> Put(int id, [FromBody] Candidate candidate)
        {
            if (!_data.TryUpdateCandidate(id, candidate, out string message))
                return this.StatusCode(StatusCodes.Status400BadRequest, message);

            return _data.GetCandidates().First(x=>x.Id == id);
        }
        
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (!_data.TryDeleteCandidate(id, out string message))
                return this.StatusCode(StatusCodes.Status400BadRequest, message);
            return Ok();
        }
    }
}
