﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApi.Data.Entities;

namespace WebApi.Data
{
    public class EqTekData : IEqTekData
    {
        private List<Candidate> _candidates;

        public EqTekData()
        {
            _candidates = new List<Candidate>()
            {
                new Candidate(){Id = 1, Name = "Mary Jane"},
                new Candidate(){Id = 2, Name = "Bob Marley"},
                new Candidate(){Id = 3, Name = "John Rambo"},
            };
        }

        public bool TryAddCandidate(Candidate candidate, out string message)
        {
           
            message = string.Empty;
            if (string.IsNullOrEmpty(candidate.Name))
            {
                message = "Candidate with no name cannot be added";
                return false;
            }
            
            candidate.Id = _candidates.Max(x => x.Id) + 1;
            _candidates.Add(candidate);
            return true;
        }

        public bool TryDeleteCandidate(int id, out string message)
        {
            message = string.Empty;
            var _candidate = _candidates.FirstOrDefault(x => x.Id == id);

            if (_candidate == null)
            {
                message = $"Candidate with id {id} not found";
                return false;
            }

            _candidates.Remove(_candidate);
            return true;
        }

        public IEnumerable<Candidate> GetCandidates()
        {
            return _candidates;
        }

        public bool TryUpdateCandidate(int id, Candidate candidate, out string message)
        {
            message = string.Empty;
            var _candidate = _candidates.FirstOrDefault(x => x.Id == id);

            if (_candidate == null)
            {
                message = $"Candidate with id {candidate.Id} not found";
                return false;
            }

            _candidate.Name = candidate.Name;
            _candidate.Decision = candidate.Decision;
           
            return true;
        }
        
    }
}
