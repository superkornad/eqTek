﻿using System.Collections.Generic;
using WebApi.Data.Entities;

namespace WebApi.Data
{
    public interface IEqTekData
    {
        IEnumerable<Candidate> GetCandidates();
        bool TryAddCandidate(Candidate candidate, out string message);
        bool TryUpdateCandidate(int id, Candidate candidate, out string message);
        bool TryDeleteCandidate(int id, out string message);
    }
}
